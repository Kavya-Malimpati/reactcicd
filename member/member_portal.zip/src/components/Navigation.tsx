import React from 'react';
import { useRouter } from 'next/router';

const Navigation = () => {
    return (
        <nav className="bg-white shadow-sm">
            <div className="container mx-auto flex items-center justify-between py-4">
                {/* Logo Section */}
                <div className="flex items-center">
                    <div className="mr-2 ml-4">
                        <img
                            src="/Logo.png"
                            alt="Pure Insurance Logo"
                            className="h-8"
                        />
                    </div>
                    <span className="text-gray-500 font-light text-lg">Broker Portal</span>
                </div>

                {/* Navigation Section */}
                <div className="flex space-x-4 pr-2">
                    <button className="px-2 py-2 text-gray-600 font-medium uppercase cursor-pointer">HOME</button>
                    <button className="px-2 py-2 text-teal-600 font-medium uppercase cursor-pointer">Policies</button>
                    <button className="px-2 py-2 text-teal-600 font-medium uppercase cursor-pointer">Billing</button>
                    <button className="px-2 py-2 text-teal-600 font-medium uppercase cursor-pointer">Pure 360</button>
                    <button className="px-2 py-2 text-teal-600 font-medium uppercase cursor-pointer">Claims Tracker</button>
                    <button className="px-2 py-2 text-teal-600 font-medium uppercase cursor-pointer">Member Privileges</button>
                </div>
            </div>
        </nav>
    );
}

export default Navigation;