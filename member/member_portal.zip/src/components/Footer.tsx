import React from "react";

const Footer = () => {
  return (
    <div className="p-4 text-xs text-gray-600 border-t">
      <div>SERVICES | PURE360™</div>
    </div>
  );
};

export default Footer;