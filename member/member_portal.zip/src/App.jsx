import React from "react";
import {
	BrowserRouter as Router,
	Routes,
	Route,
	Navigate,
} from "react-router-dom";
import MemberDashboard from "./pages/MemberDashboard";

const ClaimsPage = () => <div>Claims Page Content</div>;

const App = () => {
	return (
		<Router>
			<Routes>
				<Route path="/" element={<MemberDashboard />} />
			</Routes>
		</Router>
	);
};

export default App;
