import React, {useEffect, useState} from "react";
import {
	ArrowRight,
	Clock,
	Home,
	User,
	Phone,
	Mail,
	Calendar,
	ChevronRight,
	Sidebar,
} from "lucide-react";
import SidebarMenu from "../components/SideBarMenu";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Navigation from "../components/Navigation";
import AccountInfoCard from "../components/AccountInfoCard";
import CurrentPoliciesCard from "../components/CurrentPoliciesCard";

const MemberDashboard = () => {
	const [isImpersonation, setIsImpersonation] = useState(true);

	useEffect(() => {
		// Check if the user is in impersonation mode
		const queryParams = new URLSearchParams(window.location.search);
    	const impersonationMode = queryParams.get("Impersonation");
		if (impersonationMode === "true") {
			setIsImpersonation(true);
		} else {
			setIsImpersonation(false);
		}
	}, []);
	// Member data
	const member = {
		name: "JOSEPHINE SILVERSTEIN",
		id: "12345678A012",
		memberSince: "Nov 21, 2019",
	};

	return (
		<div className="min-h-screen bg-gray-100">
			{/* Top yellow banner */}
			{isImpersonation && (
			<div className="bg-yellow-300 py-2 px-4 flex items-center justify-center text-sm font-medium">
				<Clock size={16} className="mr-2" />
				<span>MEMBER VIEW: {member.name}</span>
				<span className="mx-2">•</span>
				<a href="#" className="hover:underline">
					Return to PURE broker portal
				</a>
			</div>)}

			{/* Main content */}
			<div className="max-w-6xl mx-auto bg-white shadow">
				<Header />

				<Navigation />

				{/* Teal header section */}
				<div className="bg-teal-600 p-8 text-white relative h-50">
					<h1 className="text-3xl font-light pt-6">Good morning</h1>
				</div>

				{/* Dashboard sections */}
				<div className="grid grid-cols-12 gap-4 p-4 -mt-20 relative z-10">
					 {/* Sidebar */}
					<div className="col-span-3">
						<SidebarMenu />
					</div>

					{/* Main Content */}
					<div className="col-span-9 grid grid-cols-1 gap-4">
						<AccountInfoCard />
						<CurrentPoliciesCard />
					</div>
				</div>
				<Footer />
			</div>
		</div>
	);
};

export default MemberDashboard;
